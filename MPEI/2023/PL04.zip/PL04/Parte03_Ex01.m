%% Parte 3
clear all;
%% Exercicio 1
udata=load('u.data');

% Fica apenas com as duas primeiras colunas
u = udata(1:end,1:2); 
clear udata;

% Lista de utilizadores
users = unique(u(:,1)); % IDs
Nu = length(users);

% Constroi a lista de filmes para cada utilizador

Set = cell(Nu,1); % Usa celulas

% Para cada utilizador
for n = 1:Nu
    % Obtem os filmes de cada um
    ind = find(u(:,1) == users(n));
    % E guarda num array. 
    Set{n} = [Set{n} u(ind,2)];
end

% Calcula a distancia de Jaccard entre todos os pares pela definicao.
J=zeros(Nu,Nu); % array para guardar distancias
t = tic;
h= waitbar(0,'Calculating');
for n1= 1:Nu
    waitbar(n1/Nu,h);
    for n2= n1+1:Nu
        I = intersect(Set{n1}, Set{n2});
        U = union(Set{n1}, Set{n2});
        J(n1, n2) = 1 - length(I)/length(U);
        
    end
end
delete (h)
toc(t)

% Com base na distˆancia, determina pares com distancia inferior a um limiar pre-definido
threshold = 0.4; % limiar de decisao

% Array para guardar pares similares (user1, user2, distancia)
SimilarUsers= zeros(1,3);
k= 1;
for n1= 1:Nu
    for n2= n1+1:Nu
        if J(n1, n2) < threshold
            SimilarUsers(k,:)= [users(n1) users(n2) J(n1,n2)];
            k= k+1;
        end
    end
end

SimilarUsers = sortrows(SimilarUsers,3)