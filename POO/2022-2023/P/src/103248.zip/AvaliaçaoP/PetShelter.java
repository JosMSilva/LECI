package AvaliaçãoP;

public class PetShelter {
    
}
